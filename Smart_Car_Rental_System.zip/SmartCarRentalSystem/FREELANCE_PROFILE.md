# Freelance Profile Text: Smart Car Rental System

## Short title
**Car Rental Management System: ASP.NET Core MVC web app + C# console tool**

## Portfolio description (copy/paste)
I built a car-rental management system for a rental branch, covering everything from fleet browsing to returns and late fees. It runs as a secure web application and as a lightweight console tool that share the same business rules.

**What it does**
- User registration and login with role-based access (Admin and Customer)
- Live fleet catalogue with status badges: Available, Rented, Maintenance
- One-click rental flow with automatic 14-day due dates
- Return processing with automatic late-fee calculation (150 EGP per overdue day)
- Admin area to register drivers and review each driver's full rental history
- Dashboard with total fleet, available cars and driver count
- Input validation on names, phone numbers and emails

**How it is built**
- C# and .NET 10, ASP.NET Core MVC with Razor views
- Entity Framework Core with SQLite and code-first migrations (auto-applied at startup)
- ASP.NET Core Identity for authentication, authorization and roles
- Reusable class library shared with a menu-driven console application
- Responsive dark UI built on Bootstrap 5

**Skills demonstrated**
C#, ASP.NET Core MVC, Entity Framework Core, SQL / SQLite, ASP.NET Core Identity, role-based authorization, object-oriented design, layered architecture, input validation, database migrations, Git-ready project structure.

## Short pitch (for proposals)
> I can build you a booking / rental management system like this one: user accounts, role-based access, inventory with live status, transactions with due dates and automatic fees, and an admin area. I deliver clean, documented C# / ASP.NET Core code with a database that sets itself up on first run.

## One-liner (for profile headline or CV)
Built a full-stack car rental management system with ASP.NET Core MVC, EF Core and Identity (roles, rentals, returns, automatic late fees).

## Good fits for similar jobs
Rental or booking systems, inventory trackers, small-business admin dashboards, CRUD web apps with login, C# console tools.
