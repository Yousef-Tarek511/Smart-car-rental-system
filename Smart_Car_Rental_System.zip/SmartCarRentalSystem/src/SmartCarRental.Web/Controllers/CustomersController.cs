using CarRentalLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartCarRental.Web.Data.Models;

namespace SmartCarRental.Web.Controllers;

[Authorize(Roles = "Admin")]
public class CustomersController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<CustomersController> _logger;

    public CustomersController(ApplicationDbContext context, ILogger<CustomersController> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<IActionResult> Index()
    {
        try
        {
            var customers = await _context.Customers
                .Include(c => c.Rentals)
                .OrderBy(c => c.Name)
                .ToListAsync();
            return View(customers);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading customers list");
            return View(new List<Customer>());
        }
    }

    public async Task<IActionResult> Details(string? id)
    {
        if (string.IsNullOrWhiteSpace(id))
            return RedirectToAction(nameof(Index));

        try
        {
            var customer = await _context.Customers
                .Include(c => c.Rentals)
                .ThenInclude(r => r.Car)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (customer == null)
            {
                TempData["Error"] = "Driver not found in the system.";
                return RedirectToAction(nameof(Index));
            }

            return View(customer);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading customer details for {CustomerId}", id);
            TempData["Error"] = "An error occurred while loading driver profile.";
            return RedirectToAction(nameof(Index));
        }
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(string? name, string? phone, string? email)
    {
        // Server-side validation
        if (string.IsNullOrWhiteSpace(name))
        {
            ViewBag.Error = "Driver name is required.";
            return View();
        }

        if (string.IsNullOrWhiteSpace(phone))
        {
            ViewBag.Error = "Phone number is required.";
            return View();
        }

        try
        {
            ValidationHelper.ValidatePhone(phone);
            if (!string.IsNullOrWhiteSpace(email))
                ValidationHelper.ValidateEmail(email);
        }
        catch (InvalidOperationException ex)
        {
            ViewBag.Error = ex.Message;
            return View();
        }

        try
        {
            var customer = new Customer
            {
                Name = name.Trim(),
                Phone = phone.Trim(),
                Email = string.IsNullOrWhiteSpace(email) ? null : email.Trim(),
                BranchId = "BR-01"
            };
            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();

            TempData["Success"] = $"Driver '{customer.Name}' registered successfully.";
            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating customer");
            ViewBag.Error = "An error occurred while registering the driver. Please try again.";
            return View();
        }
    }
}
