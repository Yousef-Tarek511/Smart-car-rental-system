using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartCarRental.Web.Models;
using SmartCarRental.Web.Data.Models;

namespace SmartCarRental.Web.Controllers;

public class HomeController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<HomeController> _logger;

    public HomeController(ApplicationDbContext context, ILogger<HomeController> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<IActionResult> Index()
    {
        try
        {
            var branch = await _context.Branches.FirstOrDefaultAsync();

            ViewBag.TotalCars = await _context.Cars.CountAsync();
            ViewBag.AvailableCars = await _context.Cars.CountAsync(c => c.Status == "Available");
            ViewBag.RentedCars = await _context.Cars.CountAsync(c => c.Status == "Rented");
            ViewBag.TotalCustomers = await _context.Customers.CountAsync();
            ViewBag.ActiveRentals = await _context.RentalTransactions.CountAsync(r => r.ReturnedDate == null);

            return View(branch);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading dashboard data");
            ViewBag.TotalCars = 0;
            ViewBag.AvailableCars = 0;
            ViewBag.RentedCars = 0;
            ViewBag.TotalCustomers = 0;
            ViewBag.ActiveRentals = 0;
            return View();
        }
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
