using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartCarRental.Web.Data.Models;

namespace SmartCarRental.Web.Controllers;

[Authorize]
public class CarsController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<CarsController> _logger;

    public CarsController(ApplicationDbContext context, ILogger<CarsController> logger)
    {
        _context = context;
        _logger = logger;
    }

    [AllowAnonymous]
    public async Task<IActionResult> Index()
    {
        try
        {
            var cars = await _context.Cars.OrderBy(c => c.Make).ThenBy(c => c.Model).ToListAsync();
            return View(cars);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading cars list");
            return View(new List<Car>());
        }
    }

    [AllowAnonymous]
    public async Task<IActionResult> Details(string? id)
    {
        if (string.IsNullOrWhiteSpace(id))
            return RedirectToAction(nameof(Index));

        try
        {
            var car = await _context.Cars
                .Include(c => c.Rentals)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (car == null)
            {
                TempData["Error"] = "Vehicle not found in the system.";
                return RedirectToAction(nameof(Index));
            }

            return View(car);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading car details for {CarId}", id);
            TempData["Error"] = "An error occurred while loading vehicle details.";
            return RedirectToAction(nameof(Index));
        }
    }
}
