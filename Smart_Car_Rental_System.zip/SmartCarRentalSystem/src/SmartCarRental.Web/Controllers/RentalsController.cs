using System.Globalization;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartCarRental.Web.Data.Models;

namespace SmartCarRental.Web.Controllers;

[Authorize]
public class RentalsController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<RentalsController> _logger;

    public RentalsController(ApplicationDbContext context, ILogger<RentalsController> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<IActionResult> Rent(string? carId = null)
    {
        try
        {
            ViewBag.Customers = await GetAllowedCustomersAsync();
            ViewBag.Cars = await _context.Cars
                .Where(c => c.Status == "Available")
                .OrderBy(c => c.Make).ThenBy(c => c.Model)
                .ToListAsync();
            ViewBag.SelectedCarId = carId;
            return View();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading rental form data");
            ViewBag.Customers = new List<Customer>();
            ViewBag.Cars = new List<Car>();
            ViewBag.SelectedCarId = carId;
            ViewBag.Error = "An error occurred while loading the rental form. Please try again.";
            return View();
        }
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Rent(string? customerId, string? carId)
    {
        // Validate inputs
        if (string.IsNullOrWhiteSpace(customerId) || string.IsNullOrWhiteSpace(carId))
        {
            ViewBag.Error = "Please select both a driver and a vehicle.";
            return await ReloadRentView(carId);
        }

        try
        {
            // Verify customer exists
            var customer = await _context.Customers.FindAsync(customerId);
            if (customer == null)
            {
                ViewBag.Error = "Selected driver not found in the system.";
                return await ReloadRentView(carId);
            }

            // A normal user may only rent for their own customer profile
            if (!User.IsInRole("Admin") && customer.ApplicationUserId != User.FindFirstValue(ClaimTypes.NameIdentifier))
            {
                return Forbid();
            }

            // Verify car exists and is available
            var car = await _context.Cars.FindAsync(carId);
            if (car == null)
            {
                ViewBag.Error = "Selected vehicle not found in the system.";
                return await ReloadRentView(carId);
            }

            if (car.Status != "Available")
            {
                ViewBag.Error = $"Vehicle '{car.Make} {car.Model}' is currently not available (Status: {car.Status}).";
                return await ReloadRentView(null);
            }

            // Check if customer already has an active rental for the same car
            var existingRental = await _context.RentalTransactions
                .AnyAsync(r => r.CustomerId == customerId && r.CarId == carId && r.ReturnedDate == null);
            if (existingRental)
            {
                ViewBag.Error = "This driver already has an active rental for this vehicle.";
                return await ReloadRentView(carId);
            }

            var rental = new RentalTransaction
            {
                CarId = carId,
                CustomerId = customerId,
                RentedDate = DateTime.Now,
                DueDate = DateTime.Now.AddDays(14)
            };

            car.Status = "Rented";
            _context.RentalTransactions.Add(rental);
            await _context.SaveChangesAsync();

            TempData["Success"] = $"Rental authorized: {car.Make} {car.Model} → {customer.Name}. Due {rental.DueDate:dd/MM/yyyy}.";

            // Customers/Details is Admin-only, so normal users go back to the fleet instead
            return User.IsInRole("Admin")
                ? RedirectToAction("Details", "Customers", new { id = customerId })
                : RedirectToAction("Index", "Cars");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing rental for Customer={CustomerId}, Car={CarId}", customerId, carId);
            ViewBag.Error = "An unexpected error occurred while processing the rental. Please try again.";
            return await ReloadRentView(carId);
        }
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Return(string? carId)
    {
        if (string.IsNullOrWhiteSpace(carId))
        {
            TempData["Error"] = "No vehicle specified for return.";
            return RedirectToAction("Index", "Cars");
        }

        try
        {
            var rental = await _context.RentalTransactions
                .Include(r => r.Car)
                .FirstOrDefaultAsync(r => r.CarId == carId && r.ReturnedDate == null);

            if (rental == null)
            {
                TempData["Error"] = "No active rental found for this vehicle.";
                return RedirectToAction("Index", "Cars");
            }

            rental.ReturnedDate = DateTime.Now;
            var daysLate = (rental.ReturnedDate.Value - rental.DueDate).Days;
            rental.LateFee = daysLate > 0 ? daysLate * 150m : 0m;

            if (rental.Car != null)
            {
                rental.Car.Status = "Available";
            }

            await _context.SaveChangesAsync();

            var message = rental.LateFee > 0
                ? $"Vehicle returned successfully. Late fee: {rental.LateFee.ToString("F2", CultureInfo.InvariantCulture)} EGP ({daysLate} days overdue)."
                : "Vehicle returned successfully. No late fees.";

            TempData["Success"] = message;
            return RedirectToAction("Index", "Cars");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing return for Car={CarId}", carId);
            TempData["Error"] = "An error occurred while processing the vehicle return.";
            return RedirectToAction("Index", "Cars");
        }
    }

    /// <summary>
    /// Admins can rent for any customer; normal users only for their own profile.
    /// </summary>
    private async Task<List<Customer>> GetAllowedCustomersAsync()
    {
        var query = _context.Customers.AsQueryable();
        if (!User.IsInRole("Admin"))
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            query = query.Where(c => c.ApplicationUserId == userId);
        }
        return await query.OrderBy(c => c.Name).ToListAsync();
    }

    /// <summary>
    /// Helper: reloads the Rent view with fresh data when validation fails.
    /// </summary>
    private async Task<IActionResult> ReloadRentView(string? selectedCarId)
    {
        ViewBag.Customers = await GetAllowedCustomersAsync();
        ViewBag.Cars = await _context.Cars
            .Where(c => c.Status == "Available")
            .OrderBy(c => c.Make).ThenBy(c => c.Model)
            .ToListAsync();
        ViewBag.SelectedCarId = selectedCarId;
        return View("Rent");
    }
}
