using System.ComponentModel.DataAnnotations;

namespace SmartCarRental.Web.Data.Models;

public class Car
{
    [Key]
    public string Id { get; set; } = Guid.NewGuid().ToString();

    [Required]
    public string Make { get; set; } = string.Empty;

    [Required]
    public string Model { get; set; } = string.Empty;

    public int Year { get; set; }

    public string Condition { get; set; } = string.Empty;

    public string Status { get; set; } = "Available"; // Available, Rented, Maintenance

    public string? BranchId { get; set; }
    public Branch? Branch { get; set; }

    public ICollection<RentalTransaction> Rentals { get; set; } = new List<RentalTransaction>();
}
