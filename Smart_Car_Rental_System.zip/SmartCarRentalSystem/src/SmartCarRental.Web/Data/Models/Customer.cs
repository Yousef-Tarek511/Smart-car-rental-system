using System.ComponentModel.DataAnnotations;

namespace SmartCarRental.Web.Data.Models;

public class Customer
{
    [Key]
    public string Id { get; set; } = Guid.NewGuid().ToString();

    [Required]
    public string Name { get; set; } = string.Empty;

    [Required]
    public string Phone { get; set; } = string.Empty;

    public string? Email { get; set; }

    public DateTime JoinedDate { get; set; } = DateTime.Now;

    public string? BranchId { get; set; }
    public Branch? Branch { get; set; }

    public string? ApplicationUserId { get; set; }
    public ApplicationUser? ApplicationUser { get; set; }

    public ICollection<RentalTransaction> Rentals { get; set; } = new List<RentalTransaction>();
}
