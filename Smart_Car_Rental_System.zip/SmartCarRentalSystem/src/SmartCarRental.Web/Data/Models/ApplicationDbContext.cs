using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace SmartCarRental.Web.Data.Models;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Branch> Branches { get; set; }
    public DbSet<Car> Cars { get; set; }
    public DbSet<Customer> Customers { get; set; }
    public DbSet<RentalTransaction> RentalTransactions { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Branch>().HasData(
            new Branch 
            { 
                Id = "BR-01", 
                Name = "Elite Auto Rental - Nasr City", 
                Address = "45 Abbas El Akkad St", 
                Phone = "01099887766", 
                Hours = "Sat-Thu: 08:00 AM - 10:00 PM" 
            }
        );

        modelBuilder.Entity<Car>().HasData(
            new Car { Id = "CAR-001", Make = "Toyota", Model = "Corolla", Year = 2024, Condition = "Excellent", Status = "Available", BranchId = "BR-01" },
            new Car { Id = "CAR-002", Make = "Toyota", Model = "Corolla", Year = 2024, Condition = "Fair", Status = "Available", BranchId = "BR-01" },
            new Car { Id = "CAR-003", Make = "Hyundai", Model = "Elantra", Year = 2023, Condition = "Excellent", Status = "Available", BranchId = "BR-01" },
            new Car { Id = "CAR-004", Make = "Kia", Model = "Cerato", Year = 2022, Condition = "Poor", Status = "Maintenance", BranchId = "BR-01" }
        );

        // We won't seed customers here anymore since they will be tied to Identity users in the seeder.
        // Or we can keep them for testing if we don't link them immediately. Let's keep them and assume they are legacy customers.
        modelBuilder.Entity<Customer>().HasData(
            new Customer { Id = "CUST-001", Name = "Ahmed Kamal", Phone = "01098765432", Email = "ahmed@example.com", JoinedDate = new DateTime(2023, 1, 28), BranchId = "BR-01" },
            new Customer { Id = "CUST-002", Name = "Nour Hassan", Phone = "01155556677", Email = null, JoinedDate = new DateTime(2024, 3, 5), BranchId = "BR-01" }
        );
    }
}
