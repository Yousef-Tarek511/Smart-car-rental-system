using System.ComponentModel.DataAnnotations;

namespace SmartCarRental.Web.Data.Models;

public class RentalTransaction
{
    [Key]
    public string Id { get; set; } = Guid.NewGuid().ToString();

    [Required]
    public string CarId { get; set; } = string.Empty;
    public Car? Car { get; set; }

    [Required]
    public string CustomerId { get; set; } = string.Empty;
    public Customer? Customer { get; set; }

    public DateTime RentedDate { get; set; } = DateTime.Now;
    public DateTime DueDate { get; set; }

    public DateTime? ReturnedDate { get; set; }

    public decimal LateFee { get; set; }

    public bool IsActive => ReturnedDate == null;
}
