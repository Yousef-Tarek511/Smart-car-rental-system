using System.ComponentModel.DataAnnotations;

namespace SmartCarRental.Web.Data.Models;

public class Branch
{
    [Key]
    public string Id { get; set; } = Guid.NewGuid().ToString();

    [Required]
    public string Name { get; set; } = string.Empty;

    public string Address { get; set; } = string.Empty;

    public string Phone { get; set; } = string.Empty;

    public string Hours { get; set; } = string.Empty;

    public ICollection<Car> Cars { get; set; } = new List<Car>();
    
    public ICollection<Customer> Customers { get; set; } = new List<Customer>();
}
