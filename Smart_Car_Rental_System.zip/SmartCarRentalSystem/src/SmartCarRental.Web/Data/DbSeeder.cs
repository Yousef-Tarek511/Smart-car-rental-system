using Microsoft.AspNetCore.Identity;
using SmartCarRental.Web.Data.Models;

namespace SmartCarRental.Web.Data;

public static class DbSeeder
{
    public static async Task SeedRolesAndAdminAsync(IServiceProvider serviceProvider)
    {
        var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = serviceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var context = serviceProvider.GetRequiredService<ApplicationDbContext>();

        // 1. Seed Roles
        string[] roleNames = { "Admin", "Customer" };
        foreach (var roleName in roleNames)
        {
            var roleExist = await roleManager.RoleExistsAsync(roleName);
            if (!roleExist)
            {
                await roleManager.CreateAsync(new IdentityRole(roleName));
            }
        }

        // 2. Seed Admin User
        var config = serviceProvider.GetRequiredService<IConfiguration>();
        var env = serviceProvider.GetRequiredService<IHostEnvironment>();
        var logger = serviceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("DbSeeder");

        var adminEmail = config["Admin:Email"] ?? "admin@smartcarrental.com";
        // Production: set Admin__Password as an environment variable or user-secret.
        // Development falls back to a demo password.
        var adminPassword = config["Admin:Password"] ?? (env.IsDevelopment() ? "Admin123!" : null);
        if (adminPassword is null)
        {
            logger.LogWarning("Admin:Password is not configured; admin user was not seeded.");
            return;
        }
        var adminUser = await userManager.FindByEmailAsync(adminEmail);

        if (adminUser == null)
        {
            var newAdmin = new ApplicationUser
            {
                UserName = adminEmail,
                Email = adminEmail,
                FullName = "System Administrator",
                EmailConfirmed = true
            };
            
            var createPowerUser = await userManager.CreateAsync(newAdmin, adminPassword);
            if (createPowerUser.Succeeded)
            {
                await userManager.AddToRoleAsync(newAdmin, "Admin");
            }
        }
    }
}
