using CarRentalLibrary.Models;

namespace CarRentalLibrary.Interfaces;

public interface IRentalSystem
{
    Branch Branch { get; }
    IReadOnlyList<Car> AvailableCars { get; }
    Customer AddCustomer(string name, string phone, string email);
    RentalTransaction RentCar(string customerId, string carId);
    RentalTransaction ReturnCar(string carId);
    Customer FindCustomer(string customerId);
    Car FindCar(string carId);
}
