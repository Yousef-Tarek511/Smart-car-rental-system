namespace CarRentalLibrary.Enums;

public enum CarStatus
{
    Available,
    Rented,
    Maintenance,
    Reserved
}
