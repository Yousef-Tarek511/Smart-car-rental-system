namespace CarRentalLibrary.Models;

public class Customer
{
    private static int nextNumber;

    public Customer(string name, string phone, string? email, DateOnly joinedDate)
    {
        Id = $"CUST-{++nextNumber:000}";
        Name = name;
        Phone = phone;
        Email = email;
        JoinedDate = joinedDate;
    }

    public string Id { get; }
    public string Name { get; }
    public string Phone { get; }
    public string? Email { get; }
    public DateOnly JoinedDate { get; }
    public List<RentalTransaction> Rentals { get; } = [];
    public int ActiveRentals => Rentals.Count(rental => rental.ReturnedDate is null);
}
