namespace CarRentalLibrary.Models;

public class Branch
{
    private static int nextNumber;

    public Branch(string name, string address, string phone, string hours, Manager manager)
    {
        Id = $"BR-{++nextNumber:00}";
        Name = name;
        Address = address;
        Phone = phone;
        Hours = hours;
        Manager = manager;
    }

    public string Id { get; }
    public string Name { get; }
    public string Address { get; }
    public string Phone { get; }
    public string Hours { get; }
    public Manager Manager { get; }
    public List<Customer> Customers { get; } = [];
    public List<Car> Cars { get; } = [];
}
