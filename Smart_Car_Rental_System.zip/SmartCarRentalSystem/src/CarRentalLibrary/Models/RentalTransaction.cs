namespace CarRentalLibrary.Models;

public class RentalTransaction
{
    private static int nextNumber = 1000;
    public const decimal FeePerDay = 150m;

    public RentalTransaction(Car car, DateOnly rentedDate)
    {
        Id = ++nextNumber;
        Car = car;
        RentedDate = rentedDate;
        DueDate = rentedDate.AddDays(14);
    }

    public int Id { get; }
    public Car Car { get; }
    public DateOnly RentedDate { get; }
    public DateOnly DueDate { get; }
    public DateOnly? ReturnedDate { get; private set; }
    public decimal LateFee { get; private set; }
    public bool IsActive => ReturnedDate is null;

    public decimal CalculateFee(DateOnly returnDate)
    {
        var overdueDays = returnDate.DayNumber - DueDate.DayNumber;
        return overdueDays > 0 ? overdueDays * FeePerDay : 0m;
    }

    public void Complete(DateOnly returnDate)
    {
        if (!IsActive)
            throw new InvalidOperationException("This rental has already been returned.");

        ReturnedDate = returnDate;
        LateFee = CalculateFee(returnDate);
    }
}
