using CarRentalLibrary.Enums;

namespace CarRentalLibrary.Models;

public class Car
{
    private static int nextNumber;

    public Car(string make, string model, int year, string condition, CarStatus status = CarStatus.Available)
    {
        Id = $"CAR-{++nextNumber:000}";
        Make = make;
        Model = model;
        Year = year;
        Condition = condition;
        Status = status;
    }

    public string Id { get; }
    public string Make { get; }
    public string Model { get; }
    public int Year { get; }
    public string Condition { get; }
    public CarStatus Status { get; private set; }
    public RentalTransaction? ActiveRental { get; private set; }
    public string Name => $"{Make} {Model} {Year}";

    public bool IsAvailable() => Status == CarStatus.Available;

    public void EnsureAvailable()
    {
        if (!IsAvailable())
            throw new InvalidOperationException($"Car {Id} is not available (Status: {Status}).");
    }

    public void Rent(RentalTransaction rental)
    {
        EnsureAvailable();

        Status = CarStatus.Rented;
        ActiveRental = rental;
    }

    public RentalTransaction Return(DateOnly returnDate)
    {
        if (Status != CarStatus.Rented)
            throw new InvalidOperationException($"Car {Id} is not currently rented.");
        if (ActiveRental is null)
            throw new InvalidOperationException("No active transaction for this car.");

        ActiveRental.Complete(returnDate);
        var rental = ActiveRental;
        ActiveRental = null;
        Status = CarStatus.Available;
        return rental;
    }
}
