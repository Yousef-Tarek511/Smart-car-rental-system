namespace CarRentalLibrary.Models;

public class Manager
{
    private static int nextNumber;

    public Manager(string name, string phone, decimal salary, DateOnly hiredDate)
    {
        Id = $"MGR-{++nextNumber:00}";
        Name = name;
        Phone = phone;
        Salary = salary;
        HiredDate = hiredDate;
    }

    public string Id { get; }
    public string Name { get; }
    public string Phone { get; }
    public decimal Salary { get; }
    public DateOnly HiredDate { get; }
}
