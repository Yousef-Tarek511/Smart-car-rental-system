namespace CarRentalLibrary.Helpers;

public static class ValidationHelper
{
    public static void ValidateName(string? name)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new InvalidOperationException("Full name is required.");
    }

    public static void ValidatePhone(string? phone)
    {
        if (!ContainsDigit(phone))
            throw new InvalidOperationException("Phone number must contain at least one digit.");
    }

    public static void ValidateEmail(string? email)
    {
        if (!IsValidEmail(email))
            throw new InvalidOperationException("Invalid email format. Must contain '@' and '.'.");
    }

    public static bool ContainsDigit(string? value)
    {
        if (value is null) return false;

        foreach (var character in value)
        {
            if (char.IsDigit(character)) return true;
        }

        return false;
    }

    public static bool IsValidEmail(string? value) => value?.Contains('@') == true && value.Contains('.');
}
