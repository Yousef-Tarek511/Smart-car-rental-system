using CarRentalLibrary.Enums;
using CarRentalLibrary.Helpers;
using CarRentalLibrary.Interfaces;
using CarRentalLibrary.Models;

namespace CarRentalLibrary.Services;

public class RentalSystem : IRentalSystem
{
    public RentalSystem()
    {
        var manager = new Manager("Sara Ahmed", "01012345678", 9000m, new DateOnly(2019, 3, 15));
        Branch = new Branch("Elite Auto Rental - Nasr City Branch", "45 Abbas El Akkad St, Nasr City, Cairo", "01099887766", "Sat-Thu: 08:00 AM - 10:00 PM", manager);

        Branch.Customers.AddRange([
            new Customer("Ahmed Kamal", "01098765432", "ahmed@example.com", new DateOnly(2023, 1, 28)),
            new Customer("Nour Hassan", "01155556677", null, new DateOnly(2024, 3, 5)),
            new Customer("Omar Adel", "01244445566", "omar@example.com", new DateOnly(2025, 2, 10))
        ]);
        Branch.Cars.AddRange([
            new Car("Toyota", "Corolla", 2024, "Excellent"),
            new Car("Toyota", "Corolla", 2024, "Fair"),
            new Car("Hyundai", "Elantra", 2023, "Excellent"),
            new Car("Kia", "Cerato", 2022, "Poor", CarStatus.Maintenance)
        ]);

        var activeRental = new RentalTransaction(Branch.Cars[1], new DateOnly(2026, 9, 1));
        Branch.Cars[1].Rent(activeRental);
        Branch.Customers[0].Rentals.Add(activeRental);

        var returnedRental = new RentalTransaction(Branch.Cars[3], new DateOnly(2026, 8, 1));
        returnedRental.Complete(new DateOnly(2026, 8, 15));
        Branch.Customers[0].Rentals.Add(returnedRental);
    }

    public Branch Branch { get; }
    public IReadOnlyList<Car> AvailableCars => Branch.Cars.Where(car => car.Status == CarStatus.Available).ToList();

    public Customer AddCustomer(string name, string phone, string email)
    {
        ValidationHelper.ValidateName(name);
        ValidationHelper.ValidatePhone(phone);
        ValidationHelper.ValidateEmail(email);

        var customer = new Customer(name, phone, email, Today());
        Branch.Customers.Add(customer);
        return customer;
    }

    public RentalTransaction RentCar(string customerId, string carId)
    {
        var customer = FindCustomer(customerId);
        var car = FindCar(carId);
        car.EnsureAvailable();
        var rental = new RentalTransaction(car, Today());
        car.Rent(rental);
        customer.Rentals.Add(rental);
        return rental;
    }

    public RentalTransaction ReturnCar(string carId) => FindCar(carId).Return(Today());

    public Customer FindCustomer(string customerId) => Branch.Customers.FirstOrDefault(customer => customer.Id == customerId) ?? throw new InvalidOperationException("Customer not found.");
    public Car FindCar(string carId) => Branch.Cars.FirstOrDefault(car => car.Id == carId) ?? throw new InvalidOperationException("Car not found.");
    private static DateOnly Today() => DateOnly.FromDateTime(DateTime.Today);
}
