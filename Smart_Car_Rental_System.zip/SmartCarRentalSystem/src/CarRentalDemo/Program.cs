using CarRentalLibrary.Interfaces;
using CarRentalLibrary.Models;
using CarRentalLibrary.Services;
using System.Globalization;

IRentalSystem system = new RentalSystem();

while (true)
{
    ShowMenu();
    var choice = Ask("Enter your choice: ");
    Console.WriteLine();
    if (choice == "0") break;

    try
    {
        switch (choice)
        {
            case "1": ShowBranch(system.Branch); break;
            case "2": ShowUsers(system.Branch); break;
            case "3": ShowCars(system.AvailableCars, "Available Fleet:", "No available cars found."); break;
            case "4": ShowCars(system.Branch.Cars, "All Fleet", "No cars found in system."); break;
            case "5": Rent(system); break;
            case "6": Return(system); break;
            case "7": ShowHistory(system); break;
            case "8": Register(system); break;
            default: Console.WriteLine("Invalid menu choice. Please enter a number from 0 to 8."); break;
        }
    }
    catch (InvalidOperationException error) { Console.WriteLine(error.Message); }
    Console.WriteLine();
}

static void ShowMenu() => Console.WriteLine("CAR RENTAL SYSTEM - MAIN MENU\n----------------------------------\n1. Branch Information\n2. Show All Users\n3. Show Available Cars\n4. Show All Fleet\n5. Rent a Car\n6. Return a Car\n7. Customer Rental History\n8. Register New Customer\n\n0. Exit\n");
static string Ask(string text) { Console.Write(text); return Console.ReadLine()?.Trim() ?? ""; }
static string Date(DateOnly date) => date.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);

static void ShowBranch(Branch branch) => Console.WriteLine($"RENTAL BRANCH INFO\n----------------------------------\nID              : {branch.Id}\nName            : {branch.Name}\nAddress         : {branch.Address}\nPhone           : {branch.Phone}\nHours           : {branch.Hours}\nManager         : {branch.Manager.Name}\nTotal Customers : {branch.Customers.Count}\nTotal Vehicles  : {branch.Cars.Count}");

static void ShowUsers(Branch branch)
{
    var manager = branch.Manager;
    Console.WriteLine($"All Registered Users\n----------------------------------\n--- MANAGER PROFILE ---\nID : {manager.Id} | Name : {manager.Name} | Phone : {manager.Phone}\nSalary : ${manager.Salary.ToString("N2", CultureInfo.InvariantCulture)} | Hired : {Date(manager.HiredDate)}");
    foreach (var customer in branch.Customers)
        Console.WriteLine($"\n--- CUSTOMER PROFILE ---\nID : {customer.Id} | Name : {customer.Name} | Joined : {Date(customer.JoinedDate)}\nPhone : {customer.Phone} | Email : {customer.Email ?? "N/A"} | Active Rentals : {customer.ActiveRentals}");
}

static void ShowCars(IReadOnlyList<Car> cars, string title, string empty)
{
    Console.WriteLine($"{title}\n----------------------------------");
    if (cars.Count == 0) { Console.WriteLine(empty); return; }
    foreach (var car in cars) Console.WriteLine($"Car [{car.Id}] - {car.Name} | Condition: {car.Condition} | {car.Status}");
}

static void Rent(IRentalSystem system)
{
    var customerId = Ask("Enter Customer ID: ");
    var customer = system.FindCustomer(customerId);
    ShowCars(system.AvailableCars, "Available Fleet:", "No available cars found.");
    var rental = system.RentCar(customerId, Ask("Enter Car ID to rent: "));
    Console.WriteLine($"Car [{rental.Car.Id}] \"{rental.Car.Name}\" rented by {customer.Name}.\nDue date: {Date(rental.DueDate)}");
}

static void Return(IRentalSystem system)
{
    var rental = system.ReturnCar(Ask("Enter Car ID: "));
    Console.WriteLine($"Car [{rental.Car.Id}]: {rental.Car.Name} returned.");
    Console.WriteLine(rental.LateFee == 0 ? "Returned on time. No late fee." : $"Late return fee: {rental.LateFee.ToString("F2", CultureInfo.InvariantCulture)} EGP");
}

static void ShowHistory(IRentalSystem system)
{
    var customer = system.FindCustomer(Ask("Enter Customer ID: "));
    if (customer.Rentals.Count == 0) { Console.WriteLine("No rental history found."); return; }
    foreach (var rental in customer.Rentals)
        Console.WriteLine($"--- Transaction #{rental.Id} ------------------\nCar        : {rental.Car.Name}\nCar ID     : {rental.Car.Id}\nRented     : {Date(rental.RentedDate)}\nDue        : {Date(rental.DueDate)}\nReturned   : {(rental.ReturnedDate is null ? "Not returned yet" : Date(rental.ReturnedDate.Value))}\nStatus     : {(rental.ReturnedDate is null ? "Active" : "Returned")}\nFee        : {(rental.LateFee == 0 ? "None" : $"{rental.LateFee.ToString("F2", CultureInfo.InvariantCulture)} EGP")}\n");
}

static void Register(IRentalSystem system)
{
    var customer = system.AddCustomer(Ask("Enter Full Name: "), Ask("Enter Phone Number: "), Ask("Enter Email Address: "));
    Console.WriteLine($"Customer: {customer.Name} - [{customer.Id}] registered.");
}
