# Plan

1. Put reusable code in one small class library.
2. Put the interactive example in one Console demo project.
3. Keep every model, interface, and enum in its own clearly named file.
4. Validate customer name, phone, and email with a reusable helper.
5. Generate IDs automatically when a model is created.
6. Build and run the demo.
