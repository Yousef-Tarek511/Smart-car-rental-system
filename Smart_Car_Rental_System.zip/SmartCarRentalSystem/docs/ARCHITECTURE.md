# Architecture

```
CarRentalDemo (Console)
        |
CarRentalLibrary (Class Library)
├── Models      One class per file
├── Interfaces  One interface per file
├── Enums       One enum per file
├── Helpers      ValidationHelper
└── Services    RentalSystem
```

This is intentionally small: one class library and one demo project. The Console project only shows the menu and output. The class library holds the data classes and rental behavior. No repository, database, or extra layer is used.

## Automatic IDs

`Manager`, `Customer`, `Car`, `Rental`, and `Branch` generate their own IDs when constructed. Callers provide only meaningful data such as name, phone number, or car details.

`ValidationHelper` checks the required customer name, phone number, and email format before a customer is created.
