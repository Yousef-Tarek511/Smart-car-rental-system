# Progress

| Item | Status |
|---|---|
| Small class library | Complete |
| Console demo | Complete |
| Models folder, one class per file | Complete |
| Interfaces folder, one interface per file | Complete |
| Enums folder, one enum per file | Complete |
| Automatic IDs | Complete |
| Validation helper for name, phone, and email | Complete |
| Build and run test | Complete |

## Change log

- 2026-09-07: Reorganized the project into one small class library and one Console demo.
- 2026-09-07: Added automatic IDs for branches, managers, customers, cars, and rentals.
- 2026-09-07: Build passed with 0 warnings and 0 errors; the demo verified automatic customer and rental IDs.
- 2026-09-09: Added `ValidationHelper`, moved name/phone/email rules into it, and made customer/car lookup exact-match.
- 2026-09-09: Built successfully with 0 warnings and 0 errors; tested name, phone, email, exact lookup, late fee, no-history, and auto-ID paths.
